package com.CIMS.demo.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

@Entity
public class Claim {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int claimId;
	private String reason;
	private LocalDate date;
	private String status;
	
	@ManyToOne
	private Parent parent;
	
	@ManyToOne
	private List<Policy> policies;
	
	
	

}
