package com.CIMS.demo.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Child {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int childId;
	private String childName;
	private String childGender;
	private int childAge;
	private LocalDate dateOfBirth;
	
//	@ManyToOne
//	@JoinColumn(name = "parent_Id") //write nullable=false
//	private Parent parent;
//	
//	@OneToMany
//	@JoinColumn(name="claimId")
//	private Claim claim;
	
    @ManyToOne
    private Parent parent;

    @OneToMany(mappedBy = "child")
    private List<Policy> policies;
	
	
	
}
