package com.CIMS.demo.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Parent {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int parent_Id;
	private String parentName;
	private String parentGender;
	
	@Column(unique = true, nullable = false)
	private String parentEmailId;
	
	@Column(nullable = false)
	private String parentPw;
	
	@Column(nullable = false)
	private String contactNumber;
	

    @OneToMany(mappedBy = "user")
    @JsonManagedReference
    private List<Child> children;

    @OneToMany(mappedBy = "user")
    @JsonManagedReference
    private List<Transaction> transactions;

    @OneToMany(mappedBy = "user")
    @JsonManagedReference
    private List<Claim> claims;
	
//	@OneToMany(cascade = CascadeType.ALL,targetEntity=Child.class)
//	@JsonManagedReference
//	List<Child> childs;
//	
//	@ManyToMany(cascade = CascadeType.ALL,targetEntity = Policy.class)
//	@JsonManagedReference
//	List<Policy> policies;
//	
//	@OneToOne(cascade=CascadeType.ALL,targetEntity = Claim.class)
//	@JsonManagedReference
//	Claim claim;
	
	
	
	
}
