package com.CIMS.demo.repo;

public interface childRepo {

}
