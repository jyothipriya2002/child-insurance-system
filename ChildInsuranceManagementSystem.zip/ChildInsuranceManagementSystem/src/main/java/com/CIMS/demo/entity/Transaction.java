package com.CIMS.demo.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int trasactionId;
    private double amount;
    private LocalDate trasactionDate;
    private String transactionStatus; // SUCCESS, FAILED
    private String transactionMode;
    
    @ManyToOne
    private Parent parent;
    
    @ManyToOne
    private Policy policy;
    
    
}
