package com.CIMS.demo.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Policy {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int policyId;
	private LocalDate policyStartDate;
	private LocalDate policyEndDate;
	
	@ManyToOne
	private Parent parent;
	
	@ManyToOne
	private Child child;
	
    @OneToMany(mappedBy = "policy")
    private List<Claim> claims;

    public boolean isExpired() {
        return policyEndDate != null && policyEndDate.isBefore(LocalDate.now());
    }
//    it checks if the endDate is before today's date. This tells us that the policy has already ended.
}
